<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register New User</title>
<link rel="stylesheet" href="mine.css">
</head>
<body>
<h1 style="width:100px; height:10px; margin:auto;">Register</h1>

	<section class="login">
		<form action="register-user">
			<label for="username">UserName</label> 
			<input type="text" placeholder="Enter UserName" name="userName" id="username"><br>
			<label for="password">Password</label>
			<input type="text" placeholder="Enter Password" name="password" id="password"><br>
			<input type="submit" value="Register">
		</form>
	</section>
	

</body>
</html>