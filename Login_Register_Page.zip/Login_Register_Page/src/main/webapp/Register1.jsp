<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register New User</title>
<link rel="stylesheet" href="mine.css">
</head>
<body>
<h3>No user Found. Register New User?</h3>
	<section class="register">
			<h3>New User</h3>
			<a href="Register.jsp">Register</a>
			<h3>Here</h3>
		</section>
	

</body>
</html>