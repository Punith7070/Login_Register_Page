package com.mine.webPage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register-user")
public class RegisterUser extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");

		// JDBC LOGIC
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myweb_pages?user=root&password=root");
			PreparedStatement pst = conn.prepareStatement("INSERT INTO userdetails VALUES(?,?)");
			pst.setString(1, userName);
			pst.setString(2, password);
			int inserted = pst.executeUpdate();

			if (inserted > 0) {
				PrintWriter pw2 = resp.getWriter();
				pw2.print("New User Registered ");
				resp.sendRedirect("Index.jsp");
			} else {
				PrintWriter pw3 = resp.getWriter();
				pw3.print("<h1>" + userName + "Already Exists. Try another name</h1>");
				resp.sendRedirect("Register.jsp");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
