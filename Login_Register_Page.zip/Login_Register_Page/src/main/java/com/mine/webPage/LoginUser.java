package com.mine.webPage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login-user")
public class LoginUser extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");

		// JDBC LOGIC
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/myweb_pages?user=root&password=root");
			PreparedStatement pst = conn.prepareStatement(
					"SELECT password FROM userdetails WHERE userName=?");
			pst.setString(1, userName);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
//				rs.next();
				String dbPassword = rs.getString("password");
				
				if (dbPassword.equals(password)) {
					// open user welcome page
					PrintWriter pw1=resp.getWriter();
					pw1.print("Correct password welcome user");
				} else {
					// wrong password message
					PrintWriter pw2=resp.getWriter();
					pw2.print("Wrong password, Enter corrct password");
				}
			}else {
				// if no user found then display a message n frontend and suggest register
				
				resp.sendRedirect("Register1.jsp");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
